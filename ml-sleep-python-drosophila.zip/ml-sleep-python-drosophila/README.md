# ml-sleep-python-drosophila

This is my adaptation of YY Lee's code found here: https://github.com/yyenglee/ml-sleep
I adapted it to be able to use it for Drosophila and changed all the input data.
The DOI of the publication associated with the code is: https://doi.org/10.1093/sleep/zsac279

Important: To be able to run the code, please download drosophila gene info from https://ftp.ncbi.nlm.nih.gov/gene/DATA/GENE_INFO/Invertebrates/Drosophila_melanogaster.gene_info.gz. Move this files into 'REFERENCE'.


Original README:
Updated pipeline (06/21/22), rewrite the code in Python to increase efficiency.

Script used to build machine learning model to predict sleep genes. Features are built using two lines of information. <br />
  1. Genome-wide datasets with evidence of sleep genes enrichment. <br />
  2. Gene and protein knowledge from annotated gene set collections are scored using Jaccard index (JI). <br />

<br />

**Example inputs to run the ML model are prepared in 'DATA'. Follow the steps to prepare and process data as needed.**
 -  Step 1. Download human and mouse gene info from https://ftp.ncbi.nlm.nih.gov/gene/DATA/GENE_INFO/Mammalia/. Move these two files into 'REFERENCE'. <br />
 -  Step 2. Run the code in example_run_script.py. <br />
            This pipeline includes - <br />
            1. Calculate evidence factors based on the seed genes for each datasets in the genome-wide table. Select those that can provide information (maxEF>3). <br />
            2. Additional features based on gene sets annotation information and Jaccard index. <br />
            3. Three analysis could be run with this script <br />
                -  model evaluation with seed genes, <br />
                -  model evaluation with randomly assign labels, <br />
                -  predictions using random forest models. <br />
            Whether to run each of these steps is defined at the beginning of the pipeline. <br />
